# Premissas de privacidade — biometria e perímetro de ponto

> Esta funcionalidade trata **dados biométricos** e geolocalização somente para autenticar a batida de ponto. A clínica deve validar a base legal, a convenção coletiva e o aviso de privacidade com seu jurídico ou encarregado de dados antes de ativar o uso obrigatório.

| Controle | Implementação prevista | Fundamentação |
|---|---|---|
| Finalidade específica | A biometria e a localização serão usadas apenas na autenticação da batida de ponto. | LGPD, princípios de finalidade, adequação e necessidade [1] |
| Consentimento destacado | O recepcionista deverá aceitar um aviso específico antes do cadastro facial. | LGPD, arts. 8º e 11 [1] |
| Dados mínimos | O sistema guardará o descritor facial de comparação, a hora, a precisão e o resultado do perímetro; evitará reuso para vigilância. | LGPD, art. 6º [1] |
| Segurança e auditoria | Ações terão registo de data, utilizador e resultado; ajustes exigem justificativa do master. | LGPD, arts. 6º e 46; orientações da ANPD [2] |
| Alternativa humana | Falha de câmera, reconhecimento ou localização será tratada como exceção auditada pelo master, sem bloqueio automático de salário. | Princípios de não discriminação, transparência e revisão [1] [2] |
| Limites técnicos | Detecção/reconhecimento facial sem prova de vida certificada não elimina a necessidade de revisão humana em casos de erro. | Alertas da ANPD sobre riscos de falsos positivos e impactos discriminatórios [2] |

## Referências

[1] [Planalto — Lei Geral de Proteção de Dados Pessoais, Lei nº 13.709/2018](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/L13709compilado.htm)

[2] [ANPD — Tomada de Subsídios: dados pessoais sensíveis e dados biométricos](https://www.gov.br/participamaisbrasil/ts-dados-biometricos)

[3] [Serpro — Dados sensíveis na LGPD](https://www.serpro.gov.br/lgpd/menu/protecao-de-dados/dados-sensiveis-lgpd)
