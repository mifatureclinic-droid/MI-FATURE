# Fontes públicas de logótipos dos convênios

| Convênio | Fonte institucional | Imagem selecionada ou disponibilidade |
| --- | --- | --- |
| AFFEAM Saúde | https://affeam.com.br/affeam-saude/ | https://affeam.com.br/wp-content/uploads/2024/02/logo-titulo2.png |
| CONAB | https://www.gov.br/conab/pt-br/comunicacao-institucional/eventos-e-promocao-institucional/instrucoes-para-o-uso-da-marca | https://www.gov.br/conab/pt-br/comunicacao-institucional/eventos-e-promocao-institucional/instrucoes-para-o-uso-da-marca/logo-conab-vertical_1.jpg |
| Luminar Saúde | https://luminarsaude.org.br/ | https://luminarsaude.org.br/wp-content/uploads/2024/11/Luminar-horizontal-cor.png |
| Petrobras AMS | https://saudepetrobras.com.br/a-saude-petrobras/nossa-marca/ | https://saudepetrobras.com.br/data/files/5F/D3/80/3D/FDFEB7108831CAB7004CF9C2/logo_desktop.svg |
| Proasa Pará | https://para.proasasaude.com.br/ | https://para.proasasaude.com.br/wp-content/uploads/2025/01/preferencial2-768x242.png |
| Proasa Saúde | https://proasasaude.com.br/ | https://proasasaude.com.br/wp-content/uploads/2025/01/logo-footer.svg |
| Saúde Caixa | https://saude.caixa.gov.br/ | https://saude.caixa.gov.br/content/img/logo_portal_rel.png |
| Vale Saúde | https://www.valesaude.com.br/ | https://imagens.valesaude.com.br/images/logo_2_44087420b5_5c889acc0c_1_5b7186810b.webp |

Para Bradesco Saúde, GEAP, Mediservice, OAB e Postal Saúde, foram localizadas marcas em fontes públicas de busca; a interface utiliza os arquivos selecionados como ativos de referência. Particular não possui marca institucional.
