# Premissas legais — Ponto eletrônico

> Este módulo começa como **controle interno de jornada**, com trilha de auditoria e apuração transparente. A adoção como REP-P ou REP-A para fins regulatórios exige requisitos técnicos, registros e, conforme o caso, acordo coletivo ou providências adicionais da empresa.

| Tema | Premissa usada no sistema | Fonte oficial |
|---|---|---|
| Jornada padrão | Configurável por recepcionista; referência padrão de até 8 horas diárias e 44 semanais. | Constituição, art. 7º, XIII; síntese do TST [1] |
| Tolerância | Até 5 minutos por marcação, com limite de 10 minutos no dia, tratada como tolerância configurável e exibida no espelho. | CLT, art. 58, §1º [2] |
| Horas extras | Apuração separada das horas normais; adicional padrão configurável de 50%, respeitando contrato e instrumento coletivo. | CLT, art. 59; síntese do TST [1] |
| Intervalo | Jornada e intervalo são configuráveis pelo master; o cálculo desconta somente o intervalo efetivamente registrado. | CLT, art. 71; síntese do TST [1] |
| Ponto eletrônico | O trabalhador deve ter acesso às próprias marcações e aos comprovantes recentes. A solução preserva marcações, registra correções justificadas e permite espelho mensal. | Perguntas e Respostas da Portaria 671/2021 [3] |

## Limites da primeira versão

O sistema não deve ser apresentado como REP-P/REP-A certificado nesta etapa. Para uso como REP-P ou REP-A, a clínica deve validar os requisitos técnicos, os documentos e a convenção/acordo coletivo aplicável com contador ou jurídico trabalhista.

## Referências

[1] [TST — Jornada de trabalho: conheça as particularidades](https://www.tst.jus.br/en/jornada-de-trabalho)

[2] [Planalto — Consolidação das Leis do Trabalho](https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452compilado.htm)

[3] [Ministério do Trabalho e Emprego — Perguntas e Respostas da Portaria nº 671/2021](https://www.gov.br/trabalho-e-emprego/pt-br/assuntos/inspecao-do-trabalho/fiscalizacao-do-trabalho/Perguntas%20e%20Respostas%20REP)
