# Validação de links de assinatura — Dra. Jéssica — 13/08/2026

Foi aberta a página pública de assinatura do token recém-gerado para **Ian Victor da Conceição Silva**. A página carregou sem erro de token e exibiu, de forma consistente, a CLÍNICA CLIPSI, a profissional JESSICA MAIA VITAL, o convênio BRADESCO SAUDE, a guia `JES0001830563`, o procedimento `50000470 — Sessão em Psicoterapia Individual por Psicólogo` e a sessão de 13/08/2026.

Portanto, foi comprovada a resolução pública do token validado, com a página de assinatura pronta para uso pelo paciente.
