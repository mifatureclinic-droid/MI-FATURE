# Validação de links de assinatura — Nayara — 13/08/2026

Foi aberta a página pública de assinatura do token gerado para **José Sampaio Sobrinho**. A página carregou sem erro de token e exibiu de forma consistente a CLÍNICA CLIPSI, a profissional NAYARA MARQUES DA SILVA TAVARES, o convênio POSTAL SAUDE (CORREIOS), a guia `NAY0003450041`, o procedimento `50000470 — Sessão em Psicoterapia Individual por Psicólogo` e a sessão de 13/08/2026.

Esta verificação comprova que o token testado está sincronizado e que a página pública está disponível para assinatura.
