# Validação de links de assinatura — Suzy — 14/08/2026

Foi aberta a página pública de assinatura do token emitido para **Ana Clara da Frota Lima**. A página carregou sem erro de token e apresentou a CLÍNICA CLIPSI, a profissional SUZY JESUS DA SILVA, o convênio BRADESCO SAUDE, a guia `AMN0001830646`, o procedimento `50000470 — Sessão em Psicoterapia Individual por Psicólogo` e a sessão de 14/08/2026.

Esta validação comprova que o token testado está sincronizado nas tabelas de controle e disponível na página pública para assinatura.
